package com.cg.bankapp.bean;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.springframework.data.annotation.Id;

@Entity
@Table(name="bank_details")
public class Bank 
{
	@Id
	@GeneratedValue
private int accountId;
@Pattern(regexp="[A-Z][a-z]*")
private String username;
private double balance;
@Pattern(regexp="(91)||(91 )?[6-9][0-9]{9}")
private String phoneNumber;
private String password;
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public int getAccountId() {
	return accountId;
}
public void setAccountId(int accountId) {
	this.accountId = accountId;
}

public String getUsername() {
	return username;
}
public void setUsername(String username) {
	this.username = username;
}
public double getBalance() {
	return balance;
}
public void setBalance(double d) {
	this.balance = d;
}
public String getPhoneNumber() {
	return phoneNumber;
}
public void setPhoneNumber(String phoneNumber) {
	this.phoneNumber = phoneNumber;
}
}
